package com.hyperlauncher.redmia5.ui.settings

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.PrefsManager

class SettingsActivity : AppCompatActivity() {

    private val density by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0A1018.toInt())
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(32))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(header("Paramètres du launcher"))
        root.addView(subtitle("Style HyperOS • Inspiré de Nova, Lawnchair, Niagara, POCO"))

        // ACCUEIL
        root.addView(section("Accueil"))
        root.addView(switchRow("Afficher l'horloge", PrefsManager.showClock) { PrefsManager.showClock = it })
        root.addView(choiceRow("Taille de l'horloge", PrefsManager.clockSize, listOf("small", "medium", "large"), listOf("Petite", "Moyenne", "Grande")) { PrefsManager.clockSize = it })
        root.addView(switchRow("Afficher la météo", PrefsManager.showWeather) { PrefsManager.showWeather = it })
        root.addView(switchRow("Barre de recherche", PrefsManager.showSearchBar) { PrefsManager.showSearchBar = it })
        root.addView(choiceRow("Style de recherche", PrefsManager.searchBarStyle, listOf("google", "pill", "minimal"), listOf("Google", "Pillule", "Minimal")) { PrefsManager.searchBarStyle = it })
        root.addView(intRow("Colonnes de la grille", PrefsManager.gridColumns, 3, 6) { PrefsManager.gridColumns = it })
        root.addView(intRow("Lignes de la grille", PrefsManager.gridRows, 4, 8) { PrefsManager.gridRows = it })
        root.addView(switchRow("Indicateur de page", PrefsManager.pageIndicator) { PrefsManager.pageIndicator = it })
        root.addView(switchRow("Défilement du fond d'écran", PrefsManager.wallpaperScrolling) { PrefsManager.wallpaperScrolling = it })

        // ICONES
        root.addView(section("Icônes"))
        root.addView(choiceRow("Forme des icônes", PrefsManager.iconShape, listOf("squircle", "circle", "rounded", "square"), listOf("Squircle", "Cercle", "Arrondi", "Carré")) { PrefsManager.iconShape = it })
        root.addView(choiceRow("Taille des icônes", PrefsManager.iconSize, listOf("s", "m", "l"), listOf("Petite", "Moyenne", "Grande")) { PrefsManager.iconSize = it })
        root.addView(switchRow("Afficher les labels", PrefsManager.showLabels) { PrefsManager.showLabels = it })
        root.addView(intRow("Taille des labels", PrefsManager.labelSize, 10, 16) { PrefsManager.labelSize = it })
        root.addView(choiceRow("Pack d'icônes", PrefsManager.iconPack, listOf("system", "hyper", "material"), listOf("Système", "HyperOS", "Material")) { PrefsManager.iconPack = it })

        // DOCK
        root.addView(section("Dock"))
        root.addView(switchRow("Activer le dock", PrefsManager.dockEnabled) { PrefsManager.dockEnabled = it })
        root.addView(intRow("Nombre d'icônes", PrefsManager.dockIcons, 3, 7) { PrefsManager.dockIcons = it })
        root.addView(switchRow("Fond du dock", PrefsManager.dockBackground) { PrefsManager.dockBackground = it })
        root.addView(switchRow("Dock transparent", PrefsManager.dockTransparent) { PrefsManager.dockTransparent = it })

        // TIROIR
        root.addView(section("Tiroir d'applications"))
        root.addView(choiceRow("Style du tiroir", PrefsManager.drawerStyle, listOf("vertical", "horizontal", "categories"), listOf("Vertical", "Horizontal", "Catégories")) { PrefsManager.drawerStyle = it })
        root.addView(intRow("Colonnes du tiroir", PrefsManager.drawerColumns, 3, 6) { PrefsManager.drawerColumns = it })
        root.addView(switchRow("Recherche dans le tiroir", PrefsManager.drawerSearch) { PrefsManager.drawerSearch = it })
        root.addView(switchRow("Onglets (Toutes / Récentes / Favoris)", PrefsManager.drawerTabs) { PrefsManager.drawerTabs = it })
        root.addView(switchRow("Flou d'arrière-plan", PrefsManager.drawerBackgroundBlur) { PrefsManager.drawerBackgroundBlur = it })

        // GESTES
        root.addView(section("Gestes"))
        root.addView(switchRow("Glisser vers le haut → Accueil", PrefsManager.gestureSwipeUpHome) { PrefsManager.gestureSwipeUpHome = it })
        root.addView(switchRow("Glisser + maintenir → Récents", PrefsManager.gestureSwipeUpHoldRecents) { PrefsManager.gestureSwipeUpHoldRecents = it })
        root.addView(switchRow("Glisser depuis le bord → Retour", PrefsManager.gestureSwipeEdgeBack) { PrefsManager.gestureSwipeEdgeBack = it })
        root.addView(switchRow("Glisser vers le haut → Tiroir", PrefsManager.gestureSwipeUpDrawer) { PrefsManager.gestureSwipeUpDrawer = it })
        root.addView(switchRow("Glisser vers le bas → Recherche", PrefsManager.gestureSwipeDownSearch) { PrefsManager.gestureSwipeDownSearch = it })
        root.addView(switchRow("Double tap → Verrouiller", PrefsManager.gestureDoubleTapLock) { PrefsManager.gestureDoubleTapLock = it })
        root.addView(seekRow("Sensibilité des gestes", PrefsManager.gestureSensitivity) { PrefsManager.gestureSensitivity = it })

        // SIDEBAR
        root.addView(section("Barre latérale & Fenêtres"))
        root.addView(switchRow("Barre latérale", PrefsManager.sidebarEnabled) { PrefsManager.sidebarEnabled = it })
        root.addView(choiceRow("Position de la barre", PrefsManager.sidebarPosition, listOf("left", "right"), listOf("Gauche", "Droite")) { PrefsManager.sidebarPosition = it })
        root.addView(switchRow("Fenêtres flottantes", PrefsManager.floatingWindows) { PrefsManager.floatingWindows = it })

        // CONTROL CENTER
        root.addView(section("Centre de contrôle"))
        root.addView(switchRow("Activer le centre de contrôle", PrefsManager.controlCenterEnabled) { PrefsManager.controlCenterEnabled = it })
        root.addView(switchRow("Flou du centre de contrôle", PrefsManager.controlCenterBlur) { PrefsManager.controlCenterBlur = it })

        // ANIMATIONS
        root.addView(section("Animations"))
        root.addView(choiceRow("Vitesse", PrefsManager.animSpeed, listOf("slow", "normal", "fast"), listOf("Lente", "Normale", "Rapide")) { PrefsManager.animSpeed = it })
        root.addView(choiceRow("Transition", PrefsManager.animTransition, listOf("fade", "slide", "zoom", "none"), listOf("Fondu", "Glissement", "Zoom", "Aucune")) { PrefsManager.animTransition = it })

        // GAME BOOSTER
        root.addView(section("Game Booster"))
        root.addView(switchRow("Activer Game Booster", PrefsManager.gameBoosterEnabled) { PrefsManager.gameBoosterEnabled = it })
        root.addView(switchRow("Bloquer les notifications en jeu", PrefsManager.gameBoosterBlockNotif) { PrefsManager.gameBoosterBlockNotif = it })
        root.addView(switchRow("Nettoyage mémoire automatique", PrefsManager.gameBoosterCleanRam) { PrefsManager.gameBoosterCleanRam = it })

        // DIVERS
        root.addView(section("Divers"))
        root.addView(switchRow("Badges de notification", PrefsManager.notificationBadges) { PrefsManager.notificationBadges = it })
        root.addView(switchRow("Retour haptique", PrefsManager.hapticFeedback) { PrefsManager.hapticFeedback = it })
        root.addView(switchRow("Rotation auto de l'accueil", PrefsManager.autoRotateHome) { PrefsManager.autoRotateHome = it })
        root.addView(switchRow("Thème sombre", PrefsManager.isDarkTheme) {
            PrefsManager.isDarkTheme = it
            Toast.makeText(this, "Redémarrez le launcher pour appliquer", Toast.LENGTH_SHORT).show()
        })

        // SAUVEGARDE
        root.addView(section("Sauvegarde & Réinitialisation"))
        root.addView(actionRow("Réinitialiser tous les paramètres") {
            AlertDialog.Builder(this)
                .setTitle("Réinitialiser ?")
                .setMessage("Tous les réglages seront remis à zéro.")
                .setPositiveButton("Oui") { _, _ ->
                    PrefsManager.resetAll()
                    Toast.makeText(this, "Paramètres réinitialisés", Toast.LENGTH_SHORT).show()
                    recreate()
                }
                .setNegativeButton("Annuler", null)
                .show()
        })
        root.addView(actionRow("À propos de HyperLauncher V2") {
            AlertDialog.Builder(this)
                .setTitle("HyperLauncher V2")
                .setMessage("Redmi A5 HyperLauncher\nStyle HyperOS / Redmi Note 10 Pro\n\nInspiré des meilleurs launchers Play Store :\nNova, Lawnchair, Niagara, Microsoft, POCO.\n\nVersion 2.0.0 • Android 15 compatible")
                .setPositiveButton("OK", null)
                .show()
        })
    }

    private fun dp(v: Int) = (v * density).toInt()

    private fun header(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(0xFFF4F7FB.toInt())
        textSize = 24f
        setPadding(0, 0, 0, dp(4))
    }

    private fun subtitle(text: String) = TextView(this).apply {
        this.text = text
        setTextColor(0x99FFFFFF.toInt())
        textSize = 13f
        setPadding(0, 0, 0, dp(20))
    }

    private fun section(title: String) = TextView(this).apply {
        this.text = title.uppercase()
        setTextColor(0xFF1A8CFF.toInt())
        textSize = 13f
        setPadding(0, dp(20), 0, dp(10))
    }

    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        val tv = TextView(this).apply {
            text = label
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val sw = Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
        }
        row.addView(tv)
        row.addView(sw)
        return row
    }

    private fun choiceRow(label: String, current: String, values: List<String>, labels: List<String>, onChange: (String) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
            setOnClickListener {
                val idx = values.indexOf(current).coerceAtLeast(0)
                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle(label)
                    .setSingleChoiceItems(labels.toTypedArray(), idx) { d, which ->
                        onChange(values[which])
                        d.dismiss()
                        recreate()
                    }
                    .show()
            }
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 15f
        })
        val currentLabel = labels.getOrElse(values.indexOf(current)) { current }
        row.addView(TextView(this).apply {
            text = currentLabel
            setTextColor(0xFF1A8CFF.toInt())
            textSize = 13f
        })
        return row
    }

    private fun intRow(label: String, current: Int, min: Int, max: Int, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        row.addView(TextView(this).apply {
            text = "$label : $current"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 15f
        })
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = (current - min).coerceIn(0, max - min)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = progress + min
                    onChange(v)
                    (row.getChildAt(0) as? TextView)?.text = "$label : $v"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        row.addView(seek)
        return row
    }

    private fun seekRow(label: String, current: Int, onChange: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }
        row.addView(TextView(this).apply {
            text = "$label : $current"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 15f
        })
        val seek = SeekBar(this).apply {
            max = 100
            progress = current
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    onChange(progress)
                    (row.getChildAt(0) as? TextView)?.text = "$label : $progress"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        row.addView(seek)
        return row
    }

    private fun actionRow(label: String, onClick: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(16), dp(14), dp(16))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
            setOnClickListener { onClick() }
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 15f
        })
        return row
    }
}
