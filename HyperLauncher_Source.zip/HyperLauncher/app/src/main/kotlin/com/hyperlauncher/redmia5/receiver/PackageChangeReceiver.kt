package com.hyperlauncher.redmia5.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hyperlauncher.redmia5.data.AppRepository

class PackageChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        AppRepository.refresh()
    }
}
