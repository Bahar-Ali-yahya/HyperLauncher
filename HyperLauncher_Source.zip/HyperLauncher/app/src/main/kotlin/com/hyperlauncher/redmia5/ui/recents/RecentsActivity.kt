package com.hyperlauncher.redmia5.ui.recents

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hyperlauncher.redmia5.R

class RecentsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A1018.toInt())
            setPadding((20 * density).toInt(), (48 * density).toInt(), (20 * density).toInt(), (24 * density).toInt())
            gravity = android.view.Gravity.CENTER
        }
        root.addView(TextView(this).apply {
            text = "Récents"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "Les applications récentes apparaîtront ici.\n(Fonctionnalité en cours d'intégration)"
            setTextColor(0x99FFFFFF.toInt())
            textSize = 14f
            gravity = android.view.Gravity.CENTER
            setPadding(0, (24 * density).toInt(), 0, 0)
        })
        setContentView(root)
    }
}
