package com.hyperlauncher.redmia5.ui.sidebar

import android.app.Service
import android.content.Intent
import android.os.IBinder

class SidebarService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Placeholder – real implementation would show a floating sidebar
        stopSelf()
        return START_NOT_STICKY
    }
}
