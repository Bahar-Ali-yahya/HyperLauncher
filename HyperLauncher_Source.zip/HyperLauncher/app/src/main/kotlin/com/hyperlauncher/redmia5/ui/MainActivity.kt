package com.hyperlauncher.redmia5.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager
import com.hyperlauncher.redmia5.databinding.ActivityMainBinding
import com.hyperlauncher.redmia5.model.AppInfo
import com.hyperlauncher.redmia5.ui.drawer.AppDrawerFragment
import com.hyperlauncher.redmia5.ui.controlcenter.ControlCenterDialog
import com.hyperlauncher.redmia5.ui.gamebooster.GameBoosterActivity
import com.hyperlauncher.redmia5.ui.settings.SettingsActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 30_000)
        }
    }

    private val appsListener: () -> Unit = { runOnUiThread { refreshHome() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupClock()
        setupSearch()
        setupHomeGrid()
        setupDock()
        setupGestures()

        AppRepository.addListener(appsListener)
        AppRepository.refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.post(clockRunnable)
        refreshHome()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        AppRepository.removeListener(appsListener)
    }

    private fun setupClock() {
        updateClock()
        binding.weather.visibility = if (PrefsManager.showWeather) View.VISIBLE else View.GONE
    }

    private fun updateClock() {
        val now = Date()
        binding.clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        binding.date.text = SimpleDateFormat("EEE. d MMM", Locale.FRENCH).format(now)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.FRENCH) else it.toString() }
    }

    private fun setupSearch() {
        binding.searchBar.visibility = if (PrefsManager.showSearchBar) View.VISIBLE else View.GONE
        binding.searchBar.setOnClickListener {
            openDrawer()
        }
    }

    private fun setupHomeGrid() {
        binding.homeGrid.layoutManager = GridLayoutManager(this, 4)
        binding.homeGrid.adapter = HomeAdapter(emptyList()) { app ->
            AppRepository.launch(app)
        }
    }

    private fun setupDock() {
        // Will be filled in refreshHome
    }

    private fun refreshHome() {
        val homeApps = AppRepository.getHomeApps()
        (binding.homeGrid.adapter as? HomeAdapter)?.submit(homeApps)

        val dock = binding.dock
        dock.removeAllViews()
        val dockApps = AppRepository.getDockApps()
        dockApps.forEach { app ->
            val item = createDockItem(app)
            dock.addView(item)
        }
        // Add all-apps button
        val allApps = createAllAppsButton()
        dock.addView(allApps)
    }

    private fun createDockItem(app: AppInfo): View {
        val size = (56 * resources.displayMetrics.density).toInt()
        val iv = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginStart = 8
                marginEnd = 8
            }
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setOnClickListener { AppRepository.launch(app) }
            setOnLongClickListener {
                Toast.makeText(this@MainActivity, app.label, Toast.LENGTH_SHORT).show()
                true
            }
        }
        return iv
    }

    private fun createAllAppsButton(): View {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginStart = 8
                marginEnd = 8
            }
            text = "☰"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundResource(R.drawable.bg_pill)
            setOnClickListener { openDrawer() }
        }
        return tv
    }

    private fun setupGestures() {
        // Simple long-press on root for control center, swipe up for drawer handled by system-ish
        binding.root.setOnLongClickListener {
            openControlCenter()
            true
        }
    }

    private fun openDrawer() {
        AppDrawerFragment().show(supportFragmentManager, "drawer")
    }

    private fun openControlCenter() {
        ControlCenterDialog().show(supportFragmentManager, "cc")
    }

    // Exposed for fragments
    fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    fun openGameBooster() {
        startActivity(Intent(this, GameBoosterActivity::class.java))
    }
}

class HomeAdapter(
    private var items: List<AppInfo>,
    private val onClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<HomeAdapter.VH>() {

    class VH(val view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(android.R.id.icon1)
        val label: TextView = view.findViewById(android.R.id.text1)
    }

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val density = ctx.resources.displayMetrics.density
        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding((8 * density).toInt())
        }
        val icon = ImageView(ctx).apply {
            id = android.R.id.icon1
            layoutParams = LinearLayout.LayoutParams(
                (52 * density).toInt(),
                (52 * density).toInt()
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val label = TextView(ctx).apply {
            id = android.R.id.text1
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (6 * density).toInt() }
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 11f
            gravity = Gravity.CENTER
            maxLines = 1
        }
        container.addView(icon)
        container.addView(label)
        return VH(container)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.view.setOnClickListener { onClick(app) }
    }

    override fun getItemCount() = items.size
}
