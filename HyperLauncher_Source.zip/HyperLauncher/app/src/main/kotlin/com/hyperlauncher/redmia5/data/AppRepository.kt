package com.hyperlauncher.redmia5.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import com.hyperlauncher.redmia5.model.AppInfo
import java.util.concurrent.CopyOnWriteArrayList

object AppRepository {
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private var apps: List<AppInfo> = emptyList()
    private lateinit var context: Context

    fun init(ctx: Context) {
        context = ctx.applicationContext
        refresh()
    }

    fun refresh() {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        apps = resolveInfos.mapNotNull { ri ->
            try {
                val label = ri.loadLabel(pm).toString()
                val icon = ri.loadIcon(pm)
                val pkg = ri.activityInfo.packageName
                val activity = ri.activityInfo.name
                AppInfo(pkg, activity, label, icon)
            } catch (e: Exception) {
                null
            }
        }.sortedBy { it.label.lowercase() }
        listeners.forEach { it.invoke() }
    }

    fun getApps(): List<AppInfo> = apps

    fun getHomeApps(): List<AppInfo> {
        // Prefer popular ones if present, else first 8
        val preferred = listOf(
            "com.android.chrome", "com.google.android.apps.photos",
            "com.android.vending", "com.google.android.googlequicksearchbox",
            "com.whatsapp", "com.android.settings"
        )
        val result = mutableListOf<AppInfo>()
        preferred.forEach { pkg ->
            apps.find { it.packageName == pkg }?.let { result.add(it) }
        }
        if (result.size < 8) {
            apps.filter { it !in result }.take(8 - result.size).forEach { result.add(it) }
        }
        return result.take(8)
    }

    fun getDockApps(): List<AppInfo> {
        val preferred = listOf(
            "com.android.dialer", "com.android.mms",
            "com.android.chrome", "com.android.camera2"
        )
        val result = mutableListOf<AppInfo>()
        preferred.forEach { pkg ->
            apps.find { it.packageName.contains(pkg.split(".").last()) || it.packageName == pkg }?.let {
                if (it !in result) result.add(it)
            }
        }
        if (result.size < 4) {
            apps.filter { it !in result }.take(4 - result.size).forEach { result.add(it) }
        }
        return result.take(4)
    }

    fun addListener(l: () -> Unit) = listeners.add(l)
    fun removeListener(l: () -> Unit) = listeners.remove(l)

    fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            setClassName(app.packageName, app.activityName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // fallback
            val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
            launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launch?.let { context.startActivity(it) }
        }
    }
}
