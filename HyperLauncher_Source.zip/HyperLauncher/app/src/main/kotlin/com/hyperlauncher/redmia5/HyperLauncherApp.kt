package com.hyperlauncher.redmia5

import android.app.Application
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.data.PrefsManager

class HyperLauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PrefsManager.init(this)
        AppRepository.init(this)
    }
}
