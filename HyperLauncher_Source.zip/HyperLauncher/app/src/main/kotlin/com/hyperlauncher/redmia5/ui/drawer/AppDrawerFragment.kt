package com.hyperlauncher.redmia5.ui.drawer

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.hyperlauncher.redmia5.R
import com.hyperlauncher.redmia5.data.AppRepository
import com.hyperlauncher.redmia5.model.AppInfo

class AppDrawerFragment : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext(), android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(0xE0121820.toInt()))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarColor = Color.TRANSPARENT
        }
        return dialog
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val density = resources.displayMetrics.density

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * density).toInt(), (48 * density).toInt(), (20 * density).toInt(), (24 * density).toInt())
            setBackgroundColor(0xE0121820.toInt())
        }

        val search = EditText(ctx).apply {
            hint = "Rechercher des applications"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(0xFFF4F7FB.toInt())
            setBackgroundResource(R.drawable.bg_search)
            setPadding((16 * density).toInt(), (12 * density).toInt(), (16 * density).toInt(), (12 * density).toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(search)

        val tabs = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (16 * density).toInt() }
        }
        listOf("Toutes", "Récentes", "Favoris", "Catégories").forEachIndexed { i, t ->
            val tab = TextView(ctx).apply {
                text = t
                setTextColor(if (i == 0) 0xFFFFFFFF.toInt() else 0x99FFFFFF.toInt())
                textSize = 13f
                setPadding((14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt())
                setBackgroundResource(if (i == 0) R.drawable.bg_pill else 0)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = (8 * density).toInt() }
            }
            tabs.addView(tab)
        }
        root.addView(tabs)

        val recycler = RecyclerView(ctx).apply {
            layoutManager = GridLayoutManager(ctx, 4)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { topMargin = (16 * density).toInt() }
        }
        val adapter = DrawerAdapter(AppRepository.getApps()) { app ->
            AppRepository.launch(app)
            dismiss()
        }
        recycler.adapter = adapter
        root.addView(recycler)

        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val q = s?.toString()?.lowercase().orEmpty()
                val filtered = if (q.isEmpty()) AppRepository.getApps()
                else AppRepository.getApps().filter { it.label.lowercase().contains(q) }
                adapter.submit(filtered)
            }
        })

        return root
    }

    private class DrawerAdapter(
        private var items: List<AppInfo>,
        private val onClick: (AppInfo) -> Unit
    ) : RecyclerView.Adapter<DrawerAdapter.VH>() {

        class VH(val view: View) : RecyclerView.ViewHolder(view) {
            val icon: ImageView = view.findViewById(android.R.id.icon1)
            val label: TextView = view.findViewById(android.R.id.text1)
        }

        fun submit(list: List<AppInfo>) {
            items = list
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val density = ctx.resources.displayMetrics.density
            val p = (8 * density).toInt()
            val container = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(p, p, p, p)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            val icon = ImageView(ctx).apply {
                id = android.R.id.icon1
                layoutParams = LinearLayout.LayoutParams((48 * density).toInt(), (48 * density).toInt())
            }
            val label = TextView(ctx).apply {
                id = android.R.id.text1
                setTextColor(0xFFF4F7FB.toInt())
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (4 * density).toInt() }
            }
            container.addView(icon)
            container.addView(label)
            return VH(container)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = items[position]
            holder.icon.setImageDrawable(app.icon)
            holder.label.text = app.label
            holder.view.setOnClickListener { onClick(app) }
        }

        override fun getItemCount() = items.size
    }
}
