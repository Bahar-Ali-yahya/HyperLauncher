package com.hyperlauncher.redmia5.ui.gamebooster

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.hyperlauncher.redmia5.R

class GameBoosterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A1018.toInt())
            setPadding((20 * density).toInt(), (48 * density).toInt(), (20 * density).toInt(), (24 * density).toInt())
        }

        root.addView(TextView(this).apply {
            text = "←  Game Booster"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 20f
            setPadding(0, 0, 0, (24 * density).toInt())
            setOnClickListener { finish() }
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            val p = (20 * density).toInt()
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        card.addView(TextView(this).apply {
            text = "PUBG MOBILE"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 22f
        })
        card.addView(TextView(this).apply {
            text = "Mode performance  •  32 °C  •  Batterie 80%"
            setTextColor(0x99FFFFFF.toInt())
            textSize = 13f
            setPadding(0, (8 * density).toInt(), 0, (16 * density).toInt())
        })
        card.addView(TextView(this).apply {
            text = "  LANCER  "
            setTextColor(0xFF000000.toInt())
            textSize = 16f
            setBackgroundColor(0xFF22C55E.toInt())
            setPadding((24 * density).toInt(), (12 * density).toInt(), (24 * density).toInt(), (12 * density).toInt())
        })
        root.addView(card)

        listOf(
            "Bloquer les notifications pendant le jeu",
            "Nettoyage mémoire / Libérer de la RAM",
            "Mode performance",
            "Raccourcis",
            "Paramètres du jeu",
            "Infos système"
        ).forEach { title ->
            val row = TextView(this).apply {
                text = "●  $title"
                setTextColor(0xFFF4F7FB.toInt())
                textSize = 15f
                setBackgroundResource(R.drawable.bg_card)
                val p = (16 * density).toInt()
                setPadding(p, p, p, p)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (10 * density).toInt() }
            }
            root.addView(row)
        }

        root.addView(TextView(this).apply {
            text = "Autres jeux"
            setTextColor(0x99FFFFFF.toInt())
            textSize = 14f
            setPadding(0, (24 * density).toInt(), 0, (8 * density).toInt())
        })

        setContentView(root)
    }
}
