package com.hyperlauncher.redmia5.ui.controlcenter

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import com.hyperlauncher.redmia5.R

class ControlCenterDialog : DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = Dialog(requireContext(), android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(0xCC0A1018.toInt()))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            statusBarColor = Color.TRANSPARENT
        }
        return dialog
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val ctx = requireContext()
        val density = resources.displayMetrics.density

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * density).toInt(), (56 * density).toInt(), (20 * density).toInt(), (24 * density).toInt())
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val header = TextView(ctx).apply {
            text = "Centre de contrôle"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 18f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = (20 * density).toInt() }
        }
        root.addView(header)

        val bigRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (100 * density).toInt()
            )
        }
        bigRow.addView(makeBigTile(ctx, density, "Wi-Fi", "Connecté", true, 1f))
        bigRow.addView(makeBigTile(ctx, density, "Données mobiles", "Activées", true, 1f))
        root.addView(bigRow)

        val media = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            val p = (16 * density).toInt()
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (12 * density).toInt() }
        }
        media.addView(TextView(ctx).apply {
            text = "Aucune lecture"
            setTextColor(0x99FFFFFF.toInt())
            textSize = 14f
        })
        root.addView(media)

        val brightLabel = TextView(ctx).apply {
            text = "Luminosité"
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (16 * density).toInt() }
        }
        root.addView(brightLabel)
        val seek = SeekBar(ctx).apply {
            max = 100
            progress = 70
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(seek)

        val grid = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (16 * density).toInt() }
        }
        val toggles = listOf(
            listOf("Bluetooth", "Lampe torche", "Rotation auto", "Mode avion"),
            listOf("Silencieux", "Localisation", "Partage", "Éco. énergie"),
            listOf("Capture", "Mode sombre", "Ne pas déranger", "Éditer")
        )
        toggles.forEach { rowItems ->
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = (10 * density).toInt() }
            }
            rowItems.forEach { label ->
                row.addView(makeSmallTile(ctx, density, label))
            }
            grid.addView(row)
        }
        root.addView(grid)

        val close = TextView(ctx).apply {
            text = "Appuyez n'importe où pour fermer"
            setTextColor(0x66FFFFFF.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (24 * density).toInt() }
            setOnClickListener { dismiss() }
        }
        root.addView(close)

        root.setOnClickListener { dismiss() }
        return root
    }

    private fun makeBigTile(ctx: android.content.Context, density: Float, title: String, sub: String, on: Boolean, weight: Float): View {
        val p = (12 * density).toInt()
        val tile = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_card)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                marginEnd = (8 * density).toInt()
            }
            setOnClickListener {
                Toast.makeText(ctx, "$title (simulation)", Toast.LENGTH_SHORT).show()
            }
        }
        tile.addView(TextView(ctx).apply {
            text = title
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
        })
        tile.addView(TextView(ctx).apply {
            text = sub
            setTextColor(if (on) 0xFF22C55E.toInt() else 0x99FFFFFF.toInt())
            textSize = 12f
            gravity = Gravity.CENTER
        })
        return tile
    }

    private fun makeSmallTile(ctx: android.content.Context, density: Float, label: String): View {
        val p = (8 * density).toInt()
        val tile = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_card)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(0, (72 * density).toInt(), 1f).apply {
                marginEnd = (6 * density).toInt()
            }
            setOnClickListener {
                Toast.makeText(ctx, "$label (simulation)", Toast.LENGTH_SHORT).show()
            }
        }
        tile.addView(TextView(ctx).apply {
            text = "●"
            setTextColor(0xFF1A8CFF.toInt())
            textSize = 18f
            gravity = Gravity.CENTER
        })
        tile.addView(TextView(ctx).apply {
            text = label
            setTextColor(0xFFF4F7FB.toInt())
            textSize = 10f
            gravity = Gravity.CENTER
            maxLines = 1
        })
        return tile
    }
}
