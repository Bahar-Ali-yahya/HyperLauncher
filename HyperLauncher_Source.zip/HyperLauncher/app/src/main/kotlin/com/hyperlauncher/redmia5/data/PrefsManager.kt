package com.hyperlauncher.redmia5.data

import android.content.Context
import android.content.SharedPreferences

object PrefsManager {
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences("hyper_launcher", Context.MODE_PRIVATE)
    }

    // === Theme & Appearance ===
    var isDarkTheme: Boolean
        get() = prefs.getBoolean("dark_theme", true)
        set(v) = prefs.edit().putBoolean("dark_theme", v).apply()

    var iconShape: String
        get() = prefs.getString("icon_shape", "squircle") ?: "squircle"
        set(v) = prefs.edit().putString("icon_shape", v).apply()

    var iconSize: String
        get() = prefs.getString("icon_size", "m") ?: "m"
        set(v) = prefs.edit().putString("icon_size", v).apply()

    var showLabels: Boolean
        get() = prefs.getBoolean("show_labels", true)
        set(v) = prefs.edit().putBoolean("show_labels", v).apply()

    var labelSize: Int
        get() = prefs.getInt("label_size", 11)
        set(v) = prefs.edit().putInt("label_size", v).apply()

    var iconPack: String
        get() = prefs.getString("icon_pack", "system") ?: "system"
        set(v) = prefs.edit().putString("icon_pack", v).apply()

    // === Home Screen ===
    var gridColumns: Int
        get() = prefs.getInt("grid_cols", 4)
        set(v) = prefs.edit().putInt("grid_cols", v).apply()

    var gridRows: Int
        get() = prefs.getInt("grid_rows", 5)
        set(v) = prefs.edit().putInt("grid_rows", v).apply()

    var showSearchBar: Boolean
        get() = prefs.getBoolean("show_search", true)
        set(v) = prefs.edit().putBoolean("show_search", v).apply()

    var searchBarStyle: String
        get() = prefs.getString("search_style", "google") ?: "google"
        set(v) = prefs.edit().putString("search_style", v).apply()

    var showWeather: Boolean
        get() = prefs.getBoolean("show_weather", true)
        set(v) = prefs.edit().putBoolean("show_weather", v).apply()

    var showClock: Boolean
        get() = prefs.getBoolean("show_clock", true)
        set(v) = prefs.edit().putBoolean("show_clock", v).apply()

    var clockSize: String
        get() = prefs.getString("clock_size", "large") ?: "large"
        set(v) = prefs.edit().putString("clock_size", v).apply()

    var wallpaperScrolling: Boolean
        get() = prefs.getBoolean("wallpaper_scroll", true)
        set(v) = prefs.edit().putBoolean("wallpaper_scroll", v).apply()

    var pageIndicator: Boolean
        get() = prefs.getBoolean("page_indicator", true)
        set(v) = prefs.edit().putBoolean("page_indicator", v).apply()

    // === Dock ===
    var dockEnabled: Boolean
        get() = prefs.getBoolean("dock_enabled", true)
        set(v) = prefs.edit().putBoolean("dock_enabled", v).apply()

    var dockIcons: Int
        get() = prefs.getInt("dock_icons", 4)
        set(v) = prefs.edit().putInt("dock_icons", v).apply()

    var dockBackground: Boolean
        get() = prefs.getBoolean("dock_bg", true)
        set(v) = prefs.edit().putBoolean("dock_bg", v).apply()

    var dockTransparent: Boolean
        get() = prefs.getBoolean("dock_transparent", false)
        set(v) = prefs.edit().putBoolean("dock_transparent", v).apply()

    // === App Drawer ===
    var drawerStyle: String
        get() = prefs.getString("drawer_style", "vertical") ?: "vertical"
        set(v) = prefs.edit().putString("drawer_style", v).apply()

    var drawerColumns: Int
        get() = prefs.getInt("drawer_cols", 4)
        set(v) = prefs.edit().putInt("drawer_cols", v).apply()

    var drawerSearch: Boolean
        get() = prefs.getBoolean("drawer_search", true)
        set(v) = prefs.edit().putBoolean("drawer_search", v).apply()

    var drawerTabs: Boolean
        get() = prefs.getBoolean("drawer_tabs", true)
        set(v) = prefs.edit().putBoolean("drawer_tabs", v).apply()

    var drawerBackgroundBlur: Boolean
        get() = prefs.getBoolean("drawer_blur", true)
        set(v) = prefs.edit().putBoolean("drawer_blur", v).apply()

    var hideApps: Set<String>
        get() = prefs.getStringSet("hide_apps", emptySet()) ?: emptySet()
        set(v) = prefs.edit().putStringSet("hide_apps", v).apply()

    // === Gestures ===
    var gestureSwipeUpHome: Boolean
        get() = prefs.getBoolean("g_swipe_up_home", true)
        set(v) = prefs.edit().putBoolean("g_swipe_up_home", v).apply()

    var gestureSwipeUpHoldRecents: Boolean
        get() = prefs.getBoolean("g_swipe_up_hold", true)
        set(v) = prefs.edit().putBoolean("g_swipe_up_hold", v).apply()

    var gestureSwipeEdgeBack: Boolean
        get() = prefs.getBoolean("g_edge_back", true)
        set(v) = prefs.edit().putBoolean("g_edge_back", v).apply()

    var gestureSwipeUpDrawer: Boolean
        get() = prefs.getBoolean("g_swipe_up_drawer", true)
        set(v) = prefs.edit().putBoolean("g_swipe_up_drawer", v).apply()

    var gestureSwipeDownSearch: Boolean
        get() = prefs.getBoolean("g_swipe_down_search", true)
        set(v) = prefs.edit().putBoolean("g_swipe_down_search", v).apply()

    var gestureDoubleTapLock: Boolean
        get() = prefs.getBoolean("g_double_tap_lock", false)
        set(v) = prefs.edit().putBoolean("g_double_tap_lock", v).apply()

    var gestureSensitivity: Int
        get() = prefs.getInt("g_sensitivity", 50)
        set(v) = prefs.edit().putInt("g_sensitivity", v).apply()

    // === Sidebar & Floating ===
    var sidebarEnabled: Boolean
        get() = prefs.getBoolean("sidebar", true)
        set(v) = prefs.edit().putBoolean("sidebar", v).apply()

    var sidebarPosition: String
        get() = prefs.getString("sidebar_pos", "right") ?: "right"
        set(v) = prefs.edit().putString("sidebar_pos", v).apply()

    var floatingWindows: Boolean
        get() = prefs.getBoolean("floating", true)
        set(v) = prefs.edit().putBoolean("floating", v).apply()

    // === Control Center ===
    var controlCenterEnabled: Boolean
        get() = prefs.getBoolean("cc_enabled", true)
        set(v) = prefs.edit().putBoolean("cc_enabled", v).apply()

    var controlCenterBlur: Boolean
        get() = prefs.getBoolean("cc_blur", true)
        set(v) = prefs.edit().putBoolean("cc_blur", v).apply()

    // === Animations ===
    var animSpeed: String
        get() = prefs.getString("anim_speed", "normal") ?: "normal"
        set(v) = prefs.edit().putString("anim_speed", v).apply()

    var animTransition: String
        get() = prefs.getString("anim_transition", "fade") ?: "fade"
        set(v) = prefs.edit().putString("anim_transition", v).apply()

    // === Game Booster ===
    var gameBoosterEnabled: Boolean
        get() = prefs.getBoolean("gb_enabled", true)
        set(v) = prefs.edit().putBoolean("gb_enabled", v).apply()

    var gameBoosterBlockNotif: Boolean
        get() = prefs.getBoolean("gb_block_notif", true)
        set(v) = prefs.edit().putBoolean("gb_block_notif", v).apply()

    var gameBoosterCleanRam: Boolean
        get() = prefs.getBoolean("gb_clean_ram", true)
        set(v) = prefs.edit().putBoolean("gb_clean_ram", v).apply()

    // === Misc ===
    var notificationBadges: Boolean
        get() = prefs.getBoolean("badges", true)
        set(v) = prefs.edit().putBoolean("badges", v).apply()

    var hapticFeedback: Boolean
        get() = prefs.getBoolean("haptic", true)
        set(v) = prefs.edit().putBoolean("haptic", v).apply()

    var autoRotateHome: Boolean
        get() = prefs.getBoolean("auto_rotate", false)
        set(v) = prefs.edit().putBoolean("auto_rotate", v).apply()

    fun resetAll() {
        prefs.edit().clear().apply()
    }
}
