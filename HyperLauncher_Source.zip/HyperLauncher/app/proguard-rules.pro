# Keep launcher classes
-keep class com.hyperlauncher.redmia5.** { *; }
