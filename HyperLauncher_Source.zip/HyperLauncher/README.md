# HyperLauncher V2 – Redmi A5

Launcher Android style **HyperOS / Redmi Note 10 Pro** avec un niveau de personnalisation inspiré des meilleurs launchers du Play Store (Nova Launcher, Lawnchair, Niagara, Microsoft Launcher, POCO Launcher).

## Fonctionnalités

### Écran d’accueil
- Horloge + météo
- Barre de recherche (styles Google / Pillule / Minimal)
- Grille personnalisable (colonnes & lignes)
- Dock configurable
- Indicateur de pages
- Défilement du fond d’écran

### Tiroir d’applications
- Recherche
- Onglets (Toutes / Récentes / Favoris / Catégories)
- Style vertical / horizontal / catégories
- Flou d’arrière-plan

### Centre de contrôle
- Toggles rapides (Wi-Fi, Données, Bluetooth, Torche, etc.)
- Luminosité
- Style HyperOS

### Gestes
- Swipe up → Accueil / Tiroir / Récents
- Swipe edge → Retour
- Swipe down → Recherche
- Double tap → Verrouiller
- Sensibilité réglable

### Game Booster
- Mode performance
- Blocage notifications
- Nettoyage RAM

### Paramètres avancés (niveau Nova)
- Forme & taille des icônes
- Labels
- Packs d’icônes
- Animations (vitesse + transition)
- Barre latérale
- Fenêtres flottantes
- Badges de notification
- Thème clair / sombre
- Réinitialisation

## Compilation avec GitHub Actions

1. Crée un nouveau dépôt GitHub
2. Upload tout le contenu de ce dossier
3. Va dans l’onglet **Actions**
4. Lance le workflow **Build HyperLauncher APK**
5. Télécharge l’artifact `HyperLauncher-APK`

## Installation

1. Télécharge l’APK debug ou release
2. Installe-le sur ton téléphone
3. Appuie longuement sur l’écran d’accueil → **Paramètres d’accueil** → choisis **HyperLauncher**

## Permissions nécessaires

- Accès aux applications (QUERY_ALL_PACKAGES)
- Superposition (pour barre latérale / fenêtres flottantes)
- Statistiques d’utilisation (optionnel)

---

**Version :** 2.0.0  
**Min SDK :** 26  
**Target SDK :** 35 (Android 15)
